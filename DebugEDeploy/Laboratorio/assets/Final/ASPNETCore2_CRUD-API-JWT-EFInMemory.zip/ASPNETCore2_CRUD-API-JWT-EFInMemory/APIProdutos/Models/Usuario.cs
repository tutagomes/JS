﻿namespace APIProdutos.Models
{
    public class Usuario
    {
        public string ID { get; set; }
        public string ChaveAcesso { get; set; }
    }
}
